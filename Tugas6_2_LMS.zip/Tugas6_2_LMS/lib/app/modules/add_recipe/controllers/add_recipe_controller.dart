import 'package:get/get.dart';

class AddRecipeController extends GetxController {}
